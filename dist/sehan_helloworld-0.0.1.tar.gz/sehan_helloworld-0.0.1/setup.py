from distutils.core import setup
setup(
  name = 'sehan_helloworld',         # How you named your package folder (MyLib)
  version='0.0.1',
  description='nothing special',
  package_dir={'':'src'},
  py_modules=['helloworld']
  
)
